import { Recycle, Home, ServerCog, TrendingUp, Bell, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ThemeToggle } from "@/components/theme-toggle";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function Sidebar({ open, onOpenChange }: SidebarProps) {
  const [location, navigate] = useLocation();
  const { user } = useAuth();
  
  const navigation = [
    { name: "Dashboard", icon: Home, href: "/", current: location === "/" },
    { name: "Processes", icon: ServerCog, href: "/processes", current: location === "/processes" },
    { name: "Analytics", icon: TrendingUp, href: "/analytics", current: location === "/analytics" },
    { name: "Alerts", icon: Bell, href: "/alerts", current: false },
  ];

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-center h-16 px-4 bg-primary">
        <div className="flex items-center space-x-2">
          <Recycle className="text-white text-xl" size={24} />
          <span className="text-white text-xl font-bold">ProcessTracker</span>
        </div>
      </div>
      
      <nav className="mt-8 flex-1">
        <div className="px-4 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.name}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.1 }}
              >
                <Button
                  variant={item.current ? "secondary" : "ghost"}
                  className={`w-full justify-start ${
                    item.current 
                      ? "bg-blue-50 text-primary hover:bg-blue-50" 
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  }`}
                  onClick={() => {
                    if (item.href) {
                      // If clicking on the current page, go back to dashboard
                      if (item.current && item.href !== "/") {
                        navigate("/");
                      } else {
                        navigate(item.href);
                      }
                    }
                  }}
                  data-testid={`nav-${item.name.toLowerCase()}`}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </Button>
              </motion.div>
            );
          })}
        </div>
      </nav>
      
      {/* Bottom section with user info and controls */}
      <div className="p-4 border-t border-border">
        {/* User info */}
        {user && (
          <div className="flex items-center gap-3 mb-4">
            {user.profileImageUrl && (
              <img 
                src={user.profileImageUrl} 
                alt="Profile" 
                className="h-8 w-8 rounded-full object-cover"
              />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {user.role === 'admin' ? 'Administrator' : 'User'}
              </p>
            </div>
          </div>
        )}
        
        {/* Theme toggle and logout */}
        <div className="flex items-center justify-between">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.location.href = '/api/logout'}
            className="h-9 w-9 p-0 text-muted-foreground hover:text-foreground"
            data-testid="logout-button"
          >
            <LogOut className="h-4 w-4" />
            <span className="sr-only">Logout</span>
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-50 lg:block lg:w-64 lg:bg-white lg:shadow-lg">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="left" className="w-64 p-0">
          <SidebarContent />
        </SheetContent>
      </Sheet>
    </>
  );
}
